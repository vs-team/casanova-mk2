let AI world strategies = 
  co{
    let to_map (m:(float * StarSystem * JumpGate)[][]) : Map<StarSystem * StarSystem, float * StarSystem * JumpGate> =
      [
        for l,s in m |> Seq.zip star_systems do 
          for j,s' in l |> Seq.zip star_systems do 
            yield (s,s'),j
      ]
    // pathfinding_map.[s1,s2] = (dist,next_step_system,next_step_jump_gate)
    let pathfinding_map = [| [| ... |] |] |> all_pairs_shortest_path |> to_map
    
    // AI state contains all information about locked units by the various strategy modules; 
    // for example, if the defensive strategy is using a certain unit, then that unit is set
    // as defensive with a certain priority (so that other strategies may steal units if their
    // need is higher)
    let ai_fleets : Map<Fleet, Strategy * float> = Map.empty
    let ai_buildings : Map<Building, Strategy * float> = Map.empty
    let ai_state = { Fleets = ai_fleets; Buildings = ai_buildings }
    
    [ 
      for strategy in strategies do 
        match strategy with
        | Defensive priority -> yield defensive_strategy priority ai_state
        | Aggressive priority -> yield aggressive_strategy priority ai_state
        | Rushing priority -> yield rushing_strategy priority ai_state
        | Research priority -> yield research_strategy priority ai_state
      yield cleanup ai_state |> repeat
    ]
  }